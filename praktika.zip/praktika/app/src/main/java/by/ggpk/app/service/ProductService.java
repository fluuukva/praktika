package by.ggpk.app.service;

import by.ggpk.app.dto.ProductDto;
import by.ggpk.app.entity.Product;
import by.ggpk.app.enums.ProductCategory;
import by.ggpk.app.mapper.ProductMapper;
import by.ggpk.app.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductMapper productMapper;

    public List<ProductDto> getAllProducts(ProductCategory category) {
        List<Product> products;

        if (category == null) {
            products = productRepository.findAll();
        } else {
            products = productRepository.findAllByCategory(category);
        }

        return products.stream()
                .map(product -> productMapper.toDto(List.of(product)))
                .flatMap(List::stream) // Добавлено flatMap
                .collect(Collectors.toList());
    }
}