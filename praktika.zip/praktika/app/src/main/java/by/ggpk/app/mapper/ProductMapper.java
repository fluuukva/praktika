package by.ggpk.app.mapper;


import by.ggpk.app.dto.ProductDto;
import by.ggpk.app.entity.Product;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.math.BigDecimal;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ProductMapper {

    List<ProductDto> toDto(List<Product> products);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "name", source = "name")
    @Mapping(target = "category", source = "category")
    @Mapping(target = "price", expression = "java(convertMoney(product.getPrice()))")
    @Mapping(target = "imageUrl", source = "imageUrl")
    @Mapping(target = "quanity", source = "quanity")





    default BigDecimal convertMoney(Long cents) {
        return BigDecimal.valueOf(cents / 100L);
    }
}
