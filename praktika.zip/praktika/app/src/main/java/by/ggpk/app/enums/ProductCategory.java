package by.ggpk.app.enums;

public enum ProductCategory {

    TEA, COFFEE, ACCESSORIES
}
