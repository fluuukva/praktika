package by.ggpk.app.repository;


import by.ggpk.app.entity.Product;
import by.ggpk.app.enums.ProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    // Если вам больше не нужны данные о стоке (запасах)
    // то следует удалить эти два метода

    // @Query("SELECT p FROM Product p LEFT JOIN FETCH p.stock s")
    // List<Product> findAllWithStock();
    //
    // @Query("SELECT p FROM Product p LEFT JOIN FETCH p.stock s WHERE p.category = :category")
    // List<Product> findAllWithStockByCategory(ProductCategory category);


    // Альтернативный вариант: если вы все таки хотите получить список продуктов по категориям без stocks
    @Query("SELECT p FROM Product p WHERE p.category = :category")
    List<Product> findAllByCategory(ProductCategory category);


    // Стандартный метод, возвращает все продукты
    List<Product> findAll();


    // Пример поиска по имени продукта
    List<Product> findByNameContainingIgnoreCase(String name);



}
