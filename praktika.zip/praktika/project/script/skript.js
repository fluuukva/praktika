document.addEventListener('DOMContentLoaded', async () => {
    const cartIcon = document.querySelector('.cart-icon');
    let cart = [];
    const modalContainer = document.body;
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const cancelSearchButton = document.createElement('button');
    cancelSearchButton.textContent = 'Отменить поиск';
    cancelSearchButton.style.display = 'none';
    const hasSearchElements = searchInput && searchButton;
    if (hasSearchElements) {
        searchInput.parentNode.insertBefore(cancelSearchButton, searchInput.nextSibling);
    }

    let isDragging = false;
    let startX;
    let scrollLeft;

    function applyDragScroll(container) {
        if (!container) return;

        container.addEventListener('mousedown', (e) => {
            if (e.target.closest('.product')) return;

            e.preventDefault();
            isDragging = true;
            startX = e.pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
            container.style.cursor = 'grabbing';
        });

        container.addEventListener('mouseleave', () => {
            isDragging = false;
            container.style.cursor = 'grab';
        });

        container.addEventListener('mouseup', () => {
            isDragging = false;
            container.style.cursor = 'grab';
        });

        container.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            const x = e.pageX - container.offsetLeft;
            const walk = (x - startX) * 2;
            container.scrollLeft = scrollLeft - walk;
        });
    }

    let products;
    async function fetchProducts() {
        try {
            const response = await fetch("http://localhost:8080/api/v1/products");
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            products = await response.json();
            console.log(products);
            return products;
        } catch (error) {
            console.error('There was a problem with the fetch operation:', error);
            return null;
        }
    }
    function createProductElement(product) {
        const productElement = document.createElement('div');
        productElement.classList.add('product');
        productElement.innerHTML = `
            <img src="${product.imageUrl}" alt="${product.name}">
            <h3>${product.name}</h3>
             <p class="price-text">${product.price} BYN</p>
            <p>Всего: ${product.quanity}</p>
            <button class="add-to-cart" data-id="${product.id}">Добавить в корзину</button>
        `;

        const addToCartButton = productElement.querySelector('.add-to-cart');
        addToCartButton.addEventListener('click', () => {
            addToCart(product);
        });

        return productElement;
    }

    function addToCart(product) {
        const existingProduct = cart.find(item => item.id === product.id);
        if (existingProduct) {
            existingProduct.quantity++;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCartIcon();
        localStorage.setItem('cart', JSON.stringify(cart));
    }

    function updateCartIcon() {
        if (!cartIcon) return;
        const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartIcon.textContent = `Корзина (${totalQuantity})`;
    }

    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cart = JSON.parse(storedCart);
        updateCartIcon();
    }

    const productGridTea = document.getElementById('чай');
    const productGridCoffee = document.getElementById('кофе');
    const productGridAccessories = document.getElementById('аксессуары');
    const productGrid = document.getElementById('product-grid');
       const noResultsMessage = document.getElementById('no-results-message');


    function renderProducts(productsToRender) {
         if(productGrid) {
            productGrid.innerHTML = '';
           productsToRender.sort((a, b) => a.id - b.id);
           productsToRender.forEach(product => {
               const productElement = createProductElement(product);
               productGrid.appendChild(productElement);
           });
             if(productGrid)
              applyDragScroll(productGrid.parentNode);
    } else if (productGridTea || productGridCoffee || productGridAccessories) {

           const teaProducts = productsToRender.filter(p => p.category === 'TEA');
           const coffeeProducts = productsToRender.filter(p => p.category === 'COFFEE');
           const accessoriesProducts = productsToRender.filter(p => p.category === 'ACCESSORIES');

             if (productGridTea) {
                productGridTea.innerHTML = '';
                productGridTea.closest('.category').classList.toggle('hidden', teaProducts.length === 0);
                  teaProducts.forEach(product => {
                        const productElement = createProductElement(product);
                        productGridTea.appendChild(productElement);
                    });
             }
             if (productGridCoffee) {
                productGridCoffee.innerHTML = '';
                  productGridCoffee.closest('.category').classList.toggle('hidden', coffeeProducts.length === 0);
                coffeeProducts.forEach(product => {
                    const productElement = createProductElement(product);
                    productGridCoffee.appendChild(productElement);
                });
            }
            if (productGridAccessories) {
                  productGridAccessories.innerHTML = '';
                   productGridAccessories.closest('.category').classList.toggle('hidden', accessoriesProducts.length === 0);
                 accessoriesProducts.forEach(product => {
                    const productElement = createProductElement(product);
                    productGridAccessories.appendChild(productElement);
                });
            }
            if (productGridTea)
                applyDragScroll(productGridTea.parentNode);
            if (productGridCoffee)
                applyDragScroll(productGridCoffee.parentNode);
            if (productGridAccessories)
                applyDragScroll(productGridAccessories.parentNode);

         }
        noResultsMessage.style.display = productsToRender.length === 0 ? 'block' : 'none';
    }


    let initialProducts = await fetchProducts();

    if (initialProducts) {
        renderProducts(initialProducts);
    }

    if (hasSearchElements) {
        cancelSearchButton.addEventListener('click', () => {
            searchInput.value = '';
             searchButton.click();
        });
        searchButton.addEventListener('click', () => {
            const searchTerm = searchInput.value.toLowerCase();
            let filteredProducts;
            if (searchTerm) {
                filteredProducts = initialProducts.filter(product => {
                    return product.name.toLowerCase().includes(searchTerm) || product.category.toLowerCase().includes(searchTerm);
                });
            } else {
                filteredProducts = initialProducts;
            }
            renderProducts(filteredProducts);
            cancelSearchButton.style.display = searchTerm ? 'inline-block' : 'none';
        });
    }
});