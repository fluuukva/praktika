document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.querySelector('.cart-items');
    const cartTotal = document.getElementById('total-price');
    const checkoutButton = document.getElementById('checkout-button');
    const cartEmptyMessage = document.querySelector('.cart-empty');
     const cartIcon = document.querySelector('.cart-icon');
    const modalContainer = document.body;


    //Check for null values
    if (!cartItemsContainer || !cartTotal || !checkoutButton || !cartEmptyMessage) {
        console.error("Error: One or more elements not found in the DOM. Check basket.html");
        return;
    }


    let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')) : [];

    function updateCartUI() {
        cartItemsContainer.innerHTML = '';
        let totalPrice = 0;
         let cartCount = 0;

        if (cart.length === 0) {
            cartEmptyMessage.style.display = 'block';
            cartTotal.textContent = '0.00';
        } else {
            cartEmptyMessage.style.display = 'none';
            cart.forEach(item => {
                const cartItemElement = document.createElement('div');
                cartItemElement.classList.add('cart-item');
                const itemPrice = parseFloat(item.price);
                const itemTotal = itemPrice * item.quantity;

                cartItemElement.innerHTML = `
                    <div>
                        <p>${item.name} (Количество: ${item.quantity})</p>
                        <p>Цена за ед.: ${itemPrice.toFixed(2)} руб.</p>
                    </div>
                    <div>
                        <p>Стоимость: ${itemTotal.toFixed(2)} руб.</p>
                        <button class="remove-btn" data-product-id="${item.id}">Удалить</button>
                    </div>
                `;

                cartItemsContainer.appendChild(cartItemElement);
                totalPrice += itemTotal;
                  cartCount += item.quantity;

                const removeButton = cartItemElement.querySelector('.remove-btn');
                removeButton.addEventListener('click', () => {
                    removeItemFromCart(item.id);
                });
            });
            cartTotal.textContent = totalPrice.toFixed(2);
        }
           if (cartIcon) {
            cartIcon.textContent = `Корзина (${cartCount})`;
        }
    }

    function removeItemFromCart(productId) {
        const index = cart.findIndex(item => item.id === productId);
        if (index > -1) {
             if (cart[index].quantity > 1) {
                 cart[index].quantity--;
               } else {
                   cart.splice(index, 1);
              }
             localStorage.setItem('cart', JSON.stringify(cart));
            updateCartUI();
        }
    }
    updateCartUI();


    checkoutButton.addEventListener('click', () => {
        if (cart.length > 0) {
           createOrderFormModal();
        } else {
              alert('Корзина пуста!');
          }
    });

function createOrderFormModal() {
    const orderFormModal = document.createElement('div');
    orderFormModal.classList.add('modal');
    orderFormModal.innerHTML = `
        <div class="modal-content">
            <h3>Информация о заказе</h3>
            <form id="order-form">
                <label for="name">Имя:</label>
                <input type="text" id="name" required><br>

                 <label for="address">Адрес:</label>
                <input type="text" id="address" required><br>

                <label for="phone">Телефон:</label>
                <input type="tel" id="phone" required><br>

               <div class="modal-footer">
                <button type="submit" id="confirm-order-button">Оформить</button>
                <button type="button" id = "cancel-order-button">Отмена</button>
               </div>
           </form>
         </div>
    `;
    modalContainer.appendChild(orderFormModal);

    const form = orderFormModal.querySelector('#order-form');
    form.addEventListener('submit', (e) => {
       e.preventDefault();
         localStorage.removeItem('cart');
         cart = [];
         updateCartUI();
         createSuccessModal();
        orderFormModal.remove();
    });


     const cancelButton = orderFormModal.querySelector('#cancel-order-button');
    cancelButton.addEventListener('click', () => {
        orderFormModal.remove();
       });
}


    function createSuccessModal() {
        const successModal = document.createElement('div');
        successModal.classList.add('modal');
        successModal.innerHTML = `
            <div class="modal-content">
                <h3>Заказ оформлен!</h3>
                <p>Ваш заказ успешно оформлен.</p>
                <div class="modal-footer">
                    <button id="modal-ok-button">OK</button>
                </div>
            </div>
        `;
        modalContainer.appendChild(successModal);

        const modalOkButton = successModal.querySelector('#modal-ok-button');
        if (modalOkButton) {
            modalOkButton.addEventListener('click', () => {
                successModal.remove();
            });
        }
    }
      function closeModal() {
           const modal = document.querySelector('.modal')
             modal.remove();
    }
});